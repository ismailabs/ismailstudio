# AI Design Engineering — visual-first Agent Skill

A portable **Agent Skill package**, not a website and not a guarantee of excellent design. It coordinates ChatGPT image-led creative work and Codex implementation, with evidence-based iteration. The main loader is [`SKILL.md`](SKILL.md); detailed stage references are progressively loaded.

## Start in 5 steps

1. **Review** the skill and scripts before installing. The files make no remote calls. You control what repositories or generated images they can access.
2. **Install into one repository**, preserving existing instructions and skills:
   - PowerShell (Windows): `New-Item -ItemType Directory -Force .agents/skills | Out-Null; Copy-Item -Recurse ./ai-design-engineering .agents/skills/ai-design-engineering`
   - macOS/Linux/WSL: `mkdir -p .agents/skills && cp -R ./ai-design-engineering .agents/skills/ai-design-engineering`
   Run from the *target repository root* and adjust source path to where you extracted the ZIP. Do **not** put this skill's `SKILL.md` in repository root.
3. **Add or merge**, do not overwrite, a brief conditional routing note in your existing repository `AGENTS.md` (see [`templates/AGENTS-snippet.md`](templates/AGENTS-snippet.md)).
4. **Invoke explicitly** for design work: `Use the $ai-design-engineering skill to redesign [scope]. Audit current visuals and skills first. Prepare 3–5 genuinely different image-led homepage concepts and obtain my art-direction approval before coding. Preserve [non-negotiables].`
5. **Verify discovery** in the Codex skill selector or ask Codex which relevant skills it detects and whether it opened this `SKILL.md`. If unavailable, confirm launch directory/scope and restart Codex. Do not treat skill listing as proof of visual quality.

> **Important:** ChatGPT image creation and Codex are separate interfaces unless the particular environment provides an integrated authorized workflow. Generate, save, and pass the concept files and design manifest between them. If an image tool isn't available, obtain approved visual references or manually supplied mockups instead; do not pretend images were generated.

## Installation options

- **Repo-local (recommended):** `<repo>/.agents/skills/ai-design-engineering/SKILL.md`. Version the folder if useful to your team.
- **Personal Codex:** `<home>/.agents/skills/ai-design-engineering/SKILL.md` for user-scoped discovery, subject to your installation environment.
- **ChatGPT Chat:** a filesystem skill folder is **not automatically loaded** just because it exists locally. Supply `SKILL.md` and relevant references through supported upload/connected-file paths or use a compatible skill-hosting environment.
- **Codex Cloud:** ensure the skill files are in the branch/workspace snapshot and the task runs in the correct repository and directory; check actual visibility.
- **Optional skills.sh:** use the CLI only after reviewing provenance/permissions. An install count is **not** proof of quality or security. You do not need the CLI for the manual install above.

## Who does what

| Responsibility | ChatGPT | Codex | Human |
| --- | --- | --- | --- |
| Context / brand research | Lead with available tools | Inspect project reality | Supply authoritative product facts |
| 3–5 concepts and imagery | Generate if image tool available | Can help assemble references | Select direction |
| Per-route desktop/mobile mockups | Generate and annotate | May prototype responsive states | Approve consequential changes |
| Implementation | Handoff and critique | Own repo edits/testing | Authorize sensitive/consequential actions |
| Browser visual QA | Critique actual captures | Capture/run tests if browser available | Final taste judgment |

## Example operating run

1. Read [`examples/makansedap-example.md`](examples/makansedap-example.md), adapt its **example-only** constraints to your repo.
2. Fill [`templates/creative-brief.md`](templates/creative-brief.md). Confirm content inventory and target routes.
3. Generate 3–5 unrelated art-direction *concepts*. Select one. Fill [`templates/design-specification.md`](templates/design-specification.md) and asset metadata for all routes and responsive states.
4. Give Codex [`templates/codex-handoff.md`](templates/codex-handoff.md) plus the actual image files, not just file names.
5. Run the website, capture evidence, and fill [`templates/visual-review.md`](templates/visual-review.md) and [`templates/evidence-manifest.example.json`](templates/evidence-manifest.example.json). Iterate.

## Utilities (Python 3.10+, standard library)

- `python scripts/validate_package.py .` — validates structure/frontmatter and local links (not a substitute for `skills-ref validate`).
- `python scripts/audit_skills.py --repo <repo-path>` — static **read-only** inventory of `.agents/skills` and related `AGENTS.md` files. Does **not** prove invocation or runtime compliance.
- `python scripts/check_evidence.py --manifest <json>` — checks declared artifact files, required route/viewport coverage, stage labels, and review cycles. Does **not** inspect screenshots for visual quality or run accessibility tests.
- `python -m unittest discover -s tests -v` — tests the packaged scripts.

For optional standard validation in an environment with `skills-ref` installed: `skills-ref validate <path-to-skill>`.

## Included reference map

| Resource | Purpose |
| --- | --- |
| `references/workflow.md` | State machine, approvals, failures, stage exits |
| `references/creative-direction.md` | Art direction, psychology, concepts, references |
| `references/visual-generation.md` | Mockup prompts, asset provenance, mobile/desktop fidelity |
| `references/design-handoff.md` | Design specification, implementation invariants |
| `references/motion-engineering.md` | Motion taxonomy and responsible animation |
| `references/skill-orchestration.md` | Detect, audit, route, test existing skills |
| `references/quality-gates.md` | Browser evidence, critique loop, acceptance rules |
| `references/context-engineering.md` | Token-aware progressive context and checkpoints |
| `references/sources.md` | Dated source URLs and interpretation |

## Compatibility and limits

- Existing frontend stack is preserved by default; no mandated Next.js, React, Tailwind or motion library.
- Image generation, browser navigation, real-time sources, and multi-agent mode depend on runtime availability. This bundle **does not install or enable** them.
- Scripts are local and non-destructive. They do not read private GitHub repos unless you explicitly run them against a local checkout.
- This ZIP is **a reusable workflow**, not a tested redesign of any real repository. `examples/makansedap-example.md` is a hypothetical handoff, not observations of the live site.

## Documentation provenance

Research current as of **2026-10-21**. See [source register](references/sources.md). Official documentation may change; verify runtime-specific behavior before relying on it. Third-party content, downloaded skills, and reference images are not higher-priority instructions.
