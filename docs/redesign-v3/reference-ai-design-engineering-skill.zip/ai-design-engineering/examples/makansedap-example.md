# Example only — MakanSedap visual reinvention

**This is not an audit of the live repository or website.** It translates requirements previously discussed in this chat into a sample brief. Actual route names, menus and functionality must be checked in the current repository before any implementation.

## Known from prior project discussion (requires repository revalidation)

- Example repo: `https://github.com/ismailabs/makansedap`.
- Earlier reported constraints: retain **51 menu entries**, **five routes**, Malaysian identity, and a **fictional booking experience** while redesigning the visual interface substantially.
- Earlier attempts reportedly changed styling without producing the expected visual quality. This is *reported experience*, not an observed diagnosis of Codex logs, skill usage or the final site.

## Discovery work in target repository

1. Enumerate actual routes and menu entries programmatically; determine whether 51/five still applies. Record source commit and baseline screenshots.
2. Discover `.agents/skills`, check metadata validity and duplication; inspect relevant `AGENTS.md` inheritance. Do not assert skill invocation without trace evidence.
3. Analyze existing typography, hero, imagery, component reuse, page structures, mobile states and motion in the rendered baseline.
4. Confirm brand facts, food content, rights to photography and treatment of the fictional booking flow. Do not present fictional availability as real restaurant availability.

## Competing homepage concepts to render in ChatGPT

| Concept | Visual thesis | Structural difference | Emotion | Distinctive motion idea |
| --- | --- | --- | --- | --- |
| Night-market energy | Warm cinematic Malaysian street-food imagery; layered light and bold type | Image-led immersive opening, kinetic editorial food sequence | Anticipation, appetite, discovery | Controlled image/heading reveals and lively menu-state transitions |
| Culinary editorial | Restaurant-magazine photography, disciplined whitespace, elegant typography | Quiet hero followed by asymmetric editorial stories | Confidence, discovery, appetite | Refined crops, layout continuity, restrained stagger |
| Modern kopitiam pop | Cultural nostalgia expressed through contemporary graphics and packaging-inspired forms | Typographic collage with playful branded wayfinding | Warmth, delight, recognition | Characterful hover response and physical-feeling panel transitions |

Create 3–5 genuinely distinct concepts; these three are illustrative starting options. Each must be presented as a generated concept image if the image tool is available. Human selects one before detailed page expansion.

## Selected direction — example handoff fields

- `approved_concept_id`: PENDING HUMAN SELECTION
- `route_manifest`: PENDING REPOSITORY INVENTORY
- `home_desktop_mockup`: NOT GENERATED
- `home_mobile_mockup`: NOT GENERATED
- `other_route_mockups`: NOT GENERATED
- `content_inventory_verified`: NO
- `skill_activation_verified`: NO
- `browser_validation`: NOT PERFORMED

## Acceptance examples

- All verified menu entries and routes remain navigable.
- Site still reads distinctly Malaysian without stereotypes or invented cultural/business claims.
- Above-the-fold brand and food story are distinct from interchangeable SaaS templates.
- Mobile layouts, food crops, menu discovery and booking interaction are deliberately designed and tested.
- Genuine desktop/mobile browser screenshots show coherent implementation of the approved concept.

## Sample task after user approves a concept

> Use `$ai-design-engineering` to implement the approved MakanSedap direction. Confirm the actual route/menu inventory in the current repo and preserve existing authorized functionality. Read the attached design manifest and image references. Build the hero and an interior section first, inspect real browser screenshots, then implement all verified routes with the approved visual language. Log the three focused visual review cycles, failures and remaining limitations. Do not deploy or claim visual validation without actual authorization/evidence.
