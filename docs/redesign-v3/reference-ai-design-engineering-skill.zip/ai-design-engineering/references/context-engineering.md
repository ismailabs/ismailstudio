# Token-aware context engineering and orchestration

The objective is **better evidence and design decisions per unit of context**, not minimal tokens at any cost. Keep approved facts and current evidence; avoid rereading unrelated files or repeatedly expanding every skill.

## Four token/compute categories

| Category | Reality | Practical lever |
| --- | --- | --- |
| Input tokens | Instructions, repository snippets, user data, screenshots and tool results entering a run | Scope reads, summarize with references, avoid duplicate skill bodies |
| Output tokens | Responses, code, artifacts, review text | Produce requested artifacts and concise decision logs; reduce narration |
| Processing / reasoning tokens | Model-internal work; often hidden and not directly adjustable per step | Choose available reasoning configuration by task; simplify tasks and isolate ambiguities; don't claim direct control |
| Cached input tokens | May be reused by provider when supported; benefits depend on stable prefixes, provider/model/session and usage | Keep reusable prefix stable where relevant; don't assert cache hits without usage reporting |

## Progressive disclosure

**Layer 0: Skill metadata** — short, precise scope and trigger. **Layer 1: `SKILL.md`** — router, gates, output contract. **Layer 2: reference docs** — read only current stage. **Layer 3: repo/project files and artifact samples** — read only relevant routes, components and states. Avoid loading every third-party skill into one prompt.

## Stage-context envelope

Carry this compact record between ChatGPT, Codex and sessions, with paths to source artifacts:

```yaml
project: <name>
stage: <S0-S10>
source_commit: <commit-or-unknown>
approved_concept_id: <id-or-pending>
approved_design_version: <version-or-pending>
nonnegotiables: [<verified requirement IDs>]
route_manifest: <actual path>
asset_manifest: <actual path>
latest_browser_evidence: <actual path or missing>
open_defects: [<IDs>]
next_action: <concrete bounded action>
verified_tools: [<tools actually available>]
blocked_capabilities: [<required tool/input missing>]
```

Never replace actual references with unsupported summaries. For long multi-step projects, checkpoint this envelope after each important stage, preserving approval statements and evidence path identity.

## Context selection rules

1. First identify stage and deliverable; choose reference(s) accordingly.
2. Load only files needed for the immediate decision or code change. For a hero fix, load homepage spec + relevant components + approved hero mockup, not all pages' animation notes.
3. Prefer targeted snippets with provenance to large raw logs; link to original output for follow-up.
4. Use one authoritative document per concern (creative brief, design spec, defect log). Avoid copying full guidelines into task prompt, `AGENTS.md` and multiple skills.
5. Cache and context reuse are runtime-dependent. Keep static instruction prefixes consistent only where supported and actually economical.
6. Reserve higher reasoning/longer reviews for concept selection, major architecture, complex interactive states, and ambiguous defects. Fast/local edits can use quicker configurations when available.
7. Parallelize bounded independent *analysis* and *critique* only where tools support it; serialize edits to shared frontend files. Multiple agents do not automatically improve taste.
8. When context compacts, reconstruct from approved concept + latest manifest/defects. Revalidate live environment assumptions.

## Budget-aware gates

- **Must keep:** user-approved requirements, active file paths, exact route/content inventory, design invariants, mandatory test failures, permissions, current blockers.
- **May compress:** previous rejected concepts, old screenshot descriptions, routine command logs, historical minor defects once resolved.
- **May omit:** unused skill instructions, repetitive praise, boilerplate best practices unrelated to task, repeated design manifest content.
- **Never compress into certainty:** unknown tools, absent screenshot evidence, speculative skill activation, unmeasured visual improvement.

## What to measure in an API-backed workflow

If instrumentation exists, record input/output/cached-token counts, model/time/cost, number of review passes, route/state coverage, hard-gate failures, defects fixed, and blinded reviewer preferences. Compare baseline vs skill-assisted runs with roughly equal resources and prompts. Provider dashboards/response usage may expose different categories; don't invent universal token counters for ChatGPT or Codex.

Quality-first means accepting justified computation for actual visual refinement while eliminating unhelpful context. A shorter prompt can work better when it points to concrete examples, artifacts and verifiable outcomes.
