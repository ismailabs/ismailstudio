# From image references to a reproducible implementation

The handoff is a **contract for outcomes**, not merely a folder of pretty pictures. Complete `templates/design-specification.md` and `templates/codex-handoff.md` before full implementation. Keep the documents concise; refer to media by existing paths and versions.

## Extract six layers from approved mockups

1. **Content + semantics:** page purpose, real copy/source, page headings, actions, labels, keyboard and screen-reader structure.
2. **Composition:** major visual regions, proportions, anchoring, image subjects and crops, negative space, section order, density and rhythm.
3. **System:** typography roles, palette and contrast, spacing scales, grids, icons, surfaces, elevation only when meaningful.
4. **Responsive rules:** mobile composition is an intentional design, not a squeezed desktop; define stacking/cropping, breakpoints as behaviors, navigation, text overflow and touch targets.
5. **Interaction model:** navigation routes, hover/focus/pressed/open/disabled/error/loading/empty states, keyboard and touch behavior.
6. **Motion model:** named entrances, transition triggers, duration/easing intent, interruption, scroll behavior, reduced-motion fallback.

## Define design invariants vs engineering discretion

| Preserve as a design invariant | Codex may adapt (explain meaningful deviations) |
| --- | --- |
| Approved visual thesis and brand personality | Component architecture, CSS methodology |
| Dominant visual anchor and first-viewport hierarchy | Exact breakpoint values |
| Primary content narrative and required information | Line breaks and minor typographic adjustments |
| Distinctive typography roles, palette logic, imagery direction | Font fallback where licensing/loading constraints exist |
| Signature motion's purpose and visual continuity | Motion library or native CSS implementation |
| Visible interactive states and navigation clarity | Internal state management |

Avoid fictional pixel tolerances: image-generated references have no guaranteed design-grid coordinates. Use concrete, observable criteria: e.g., on mobile, food subject remains visible and main CTA appears before optional social proof; menu filter state survives navigation; no horizontal scroll.

## Implementation plan

- Verify existing route and content inventory before changing layout. Do not remove content or behavior without authorization.
- Identify stack, package manager and installed dependencies. Reuse current design primitives when suitable; refactor when the approved reinvention requires it.
- Implement **representative homepage hero + one interior section** and inspect before cloning a weak design to the rest of the site.
- After representative design passes visual review, implement shared tokens and components, then route-specific layouts.
- Maintain semantic HTML, meaningful alt text, focus states, usable contrast, error flows and appropriate internationalization.
- Treat animations as progressive enhancement. Avoid huge assets and unneeded dependencies. Performance check on representative mobile profile where tools allow.
- Review visual changes alongside behavior changes; changes to aesthetics often alter focus order, content hierarchy and interaction states.

## Regression prevention

Store baseline screenshots when available, then compare after each meaningful revision. Review actual code diff and routes. When a redesign intentionally changes the UI, screenshot diffs are **review prompts**, not automatic failures. Functional tests should remain stable unless authorized behavior changes are documented. Distinguish acceptable design reinterpretation from inadvertent drift.

## Example acceptance condition language

**Good:** “The home hero uses the approved street-market image treatment, clear MakanSedap brand prominence, and a single dominant order/menu CTA. At 390 px width, text does not cover food, labels remain readable, and tap targets remain operable. The menu presents all 51 original entries with filter and keyboard states intact.”

**Bad:** “Looks premium, modern, and vibrant.”

The example above is illustrative and based on previously supplied project constraints, not a live inspection of the repository.

## Build-to-design traceability

For each major invariant, record `requirement_id -> mockup_id -> implementing component/file -> evidence screenshot/state -> result`. This allows independent critique and prevents claiming fidelity without inspecting the actual output. If an aspect can only be judged subjectively, ask for explicit reviewer opinion rather than fabricating measurements.
