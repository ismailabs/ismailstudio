# Motion and microinteraction engineering

**Aim:** coherent motion that clarifies interaction and strengthens brand personality while protecting task completion, responsiveness and accessibility. Motion effects are design elements, not features to add indiscriminately.

## Motion taxonomy

| Layer | Typical use | Verification |
| --- | --- | --- |
| Input response | Hover, focus-visible, active, disabled, loading | Keyboard/touch parity; visible feedback; no input delay |
| State continuity | Filter, tabs, accordion, menu, modal | Orientation preserved; focus moved appropriately |
| View transition | Route/detail transitions | Navigation and back/forward remain functional |
| Entrance | Hero, image, heading stagger | Content remains perceivable; no cumulative blocking delay |
| Scroll reveal | Editorial section entry | Elements never remain invisible if animation fails or reduced motion is selected |
| Scroll-linked narrative | Storytelling/cinematic transformation | Mobile performance, content accessibility, sensible fallback |
| Ambient | Subtle atmosphere, cursor or parallax | Decorative only; no distraction or motion sickness risk |

Select **two or three signature motion ideas** for visual-first sites rather than giving each component a different animation identity. Dashboards may require less motion and more clear state feedback.

## Motion specification fields

For each named animation record: element / objective / trigger / initial + final state / relative sequence / approximate duration / easing intent / interruption / touch behavior / reduced-motion fallback / performance risk / verification capture.

Starting points only (not universal): button feedback ~120–200 ms, menu ~180–300 ms, reveal ~350–650 ms, page transitions ~250–500 ms. Adjust for the interface's pace, brand and actual testing. Avoid long delays before the user can act.

## Scroll choreography

- Storyboard the first three scroll beats before writing timeline code: **what arrives**, **what leaves**, **what stays anchored**, **what the visitor learns**.
- Use scroll-linked effects only when they reinforce hierarchy or narrative. Important text must remain reachable without the effect.
- Handle fast scroll, reverse scroll, resize, overscroll, motion interruption, page restoration and browser history.
- Test on narrow touch devices and moderate hardware; avoid expensive repaints and repeated layout thrashing.
- Do not hijack natural scrolling or trap users in mandatory pinned sequences without strong justification.

## Implementation guidelines

Prefer `transform` and `opacity` for compositor-friendly effects when appropriate; profile actual bottlenecks. Use CSS transitions or Web Animations API for simple effects; add a library only if complex sequencing or scroll synchronization warrants it. Follow the existing tech stack and installed dependencies. Define reusable timing/easing tokens; don't randomly mix spring systems and CSS eases across adjacent views.

Honor `prefers-reduced-motion: reduce` for nonessential movement, and avoid making anything essential accessible only through animation. Maintain focus visibility, logical focus management, text contrast, and usable controls during transitions. Never block user actions until an animation finishes. Provide a graceful no-JS or animation-failure fallback where relevant.

## Capture and critique

Static screenshots cannot prove animation quality. Capture a browser recording or a repeatable interaction trace showing the start, midpoint, end, cancellation and reduced-motion behavior when tooling supports it. Judge continuity, responsiveness, clarity, subtlety, brand fit, and mobile smoothness. Record measured performance only if actually measured, with device/profile and method; do not invent FPS claims.

## Failure patterns

- Every heading has the same slow fade-in regardless of narrative role.
- Page transitions delay navigation or hide browser focus.
- Scroll events cause jitter and inaccessible content on mobile.
- Hover-only interactions fail on touch devices.
- Motion distracts from food/product assets or important decisions.
- Reduced-motion setting leaves sections permanently hidden.

When effects fail, **remove or simplify** them before adding more libraries.
