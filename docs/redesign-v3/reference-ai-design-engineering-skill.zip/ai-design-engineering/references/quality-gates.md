# Verification protocol: evidence before confidence

Design success has **two independent dimensions**: (a) technical gates (testable) and (b) perceptual approval (evaluative). Neither can stand in for the other. Use actual rendered screenshots/recordings, not a recollection of intended styling.

## Minimum browser evidence for full workflows

1. Run app in documented local or isolated test environment; record command/URL, branch/commit if available, date, and tool.
2. Screenshot **every required route** at **mobile** and **desktop** viewports. Prefer specific dimensions in the manifest (e.g. 390×844; 1440×900); also inspect intermediate widths if layout is fragile.
3. Capture **first viewport** and **full page or representative scroll landmarks**; inspect fold, hierarchy, readability, image crop, nav and footer. Confirm the screenshot actually shows the intended page and has loaded fonts/assets.
4. Exercise relevant states (mobile menu, dialogs, filters, forms, success/errors, hover/focus, keyboard navigation, touch equivalents). Capture visual evidence and functional results.
5. Record motion by browser recording/trace if available; verify reduced-motion behavior separately. A static screenshot is not motion evidence.
6. Record console errors, broken resources, overflow, image load failures, navigation regressions, accessible labels/focus order and relevant performance findings with the actual method/tool.
7. Compare to the **approved mockup**, but identify necessary responsive differences. Do not use perceptual similarity alone as the quality judgment.

## Hard gates

| Gate | Expected evidence | Passing condition |
| --- | --- | --- |
| Core tasks/routes | Navigation/test outputs | Required user flows functional; no unintended route loss |
| Content integrity | Baseline -> final inventory | No unapproved removals or fabricated facts |
| Responsive usability | Screenshots/tested viewports | No destructive overlap, horizontal overflow or unreachable controls |
| Accessibility | Keyboard/focus/semantic review; tools if available | No known critical blocker; reduced-motion honored |
| Asset integrity | Browser load + asset register | No unapproved/missing critical images, fonts or licensing gaps |
| Functional engineering | Build/lint/tests as applicable | No introduced blocking errors |
| Motion | State recordings and reduced-motion review | Clear feedback, no blocking/unsafe motion, usable fallback |
| Visual fidelity | Side-by-side to approved references | Protected art-direction invariants present; deviations documented |
| Review coverage | Artifact list and manifests | All required pages/viewports/states reviewed, or blocked labeled |

A gate may be `PASS`, `FAIL`, `BLOCKED`, `NOT_TESTED`, or `NOT_APPLICABLE` (with reason). Do not convert absent evidence into success. **Human creative acceptance** is recorded separately (`APPROVED` / `NOT_APPROVED` / `PENDING`).

## Visual critique — observable first, taste second

Evaluate **art direction, first viewport, brand recall, focal hierarchy, copy/imagery narrative, typography craftsmanship, originality, consistency across routes, purposeful motion, and emotional coherence**. For each defect, document affected page+viewport+state, visible symptom, divergence from concept, severity, evidence path, and a proposed fix. Avoid “needs to be more premium” without specifics.

Suggested severity:
- `P0`: critical broken flow, inaccessible key interaction, major content loss, security/regression.
- `P1`: broken art-direction invariant, catastrophic mobile layout, missing hero/major asset, important interaction mismatch.
- `P2`: notable hierarchy, crop, typography or motion defect that weakens quality.
- `P3`: minor refinement with low impact.

Prioritize P0/P1 before P2/P3. Group fixes by underlying cause so one typography/token change can resolve multiple defects without repeated patches.

## Three-pass review default

- **Pass 1:** macro composition, first impression, brand, hero image, narrative.
- **Pass 2:** typography, imagery consistency, all route/state transitions, purposeful motion.
- **Pass 3:** mobile/responsive polish, accessibility interaction checks and regression verification.

This is a triage heuristic. If a P0 appears in pass 3, fix it first. Continue/reopen only for material unresolved issues with authorized time/resource budget.

## Independent comparative review

Use a baseline render and final render, same viewport/content, anonymized order when feasible. Ask reviewers for evidence-based preferences and specific weaknesses; avoid leading questions. Record disagreement. Quantitative scores may help track consistency but are not calibrated scientific measurements, and a high average cannot overrule a failed hard gate.

## Files and automated checks

`templates/evidence-manifest.example.json` gives a machine-readable example; customize route IDs. `scripts/check_evidence.py` checks that artifact paths exist and route/viewport coverage is declared. It does **not** check rendered quality, performance, a11y or the truth of review claims. Actual Playwright, browser automation, Lighthouse, axe and visual regression tools can be used if installed and authorized, but this skill does not pretend to include those runtimes or their reports.
