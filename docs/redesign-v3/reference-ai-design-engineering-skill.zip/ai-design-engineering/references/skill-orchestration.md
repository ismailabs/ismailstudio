# Skill intelligence: why installed skills may not improve design

Treat each installed skill as a candidate **bounded capability**, not a guarantee. Codex uses skill metadata to decide relevance, and installed skills can overlap, conflict, be hidden by directory scope, or be ignored. Diagnose **discovery -> selection -> invocation -> execution -> visual outcome** separately.

## Five-layer diagnostic matrix

| Layer | Question | Evidence | If missing |
| --- | --- | --- | --- |
| 1. Install | Does `SKILL.md` exist with valid metadata in scanned scope? | Filesystem path/frontmatter, repo/CWD | Fix path or YAML; validate with skills-ref |
| 2. Discover | Does current Codex session expose its name/description? | Skill selector / agent report / documented logs | Check launch directory, scope, restart, conflicting names |
| 3. Invoke | Did the task choose/read the skill? | Agent trace, explicitly requested use, file-read evidence if available | Make description trigger precise; invoke `$skill-name` explicitly |
| 4. Execute | Were relevant instructions acted upon? | Actual artifacts, commands, screenshots, decisions | Resolve instruction conflicts, missing tools and gating |
| 5. Improve | Is resulting UI visually stronger than the baseline? | Blind side-by-side human reviews + actual browser evidence | Improve context/concept/eval loop, not simply install another skill |

**Static inventory cannot prove runtime invocation.** Do not infer use from the mere presence of files or from a model's unverified self-report.

## Audit procedure

1. Inventory `.agents/skills/` under repo root and relevant ancestor scopes, plus user-level skills if accessible. Read only names, metadata and needed portions of candidate bodies. Respect private paths and do not exfiltrate skill text.
2. Check `SKILL.md` frontmatter `name`/`description`, folder-name match, references, optional tools, and duplicate names; use `python scripts/audit_skills.py --repo ...` for a first-pass local inventory. The script is read-only and cannot see remote installations.
3. Read applicable `AGENTS.md` and overrides, paying attention to location/order and whether the startup directory differs from expected repo. Build a short **instruction ownership map**.
4. Evaluate triggers: which exact user requests should activate each candidate, and which should not? Long generic descriptions invite collisions.
5. Choose one primary orchestrator, at most a small set of specialist skills for well-defined tasks (e.g., browser capture, frontend accessibility, design tokens). Do not load a dozen UI skills simultaneously.
6. Define precedence in the task: explicit user/project facts and authorized scope control outcomes; this skill coordinates the design pipeline, while a specialist advises only on its owned part. Higher-priority instructions always govern.
7. Compare before/after behavior on **representative prompts** against a baseline without that skill. Keep content/conditions comparable; do not claim causality from one screenshot.
8. Repair the smallest evidenced failure: trigger text, missing asset transport, visual gate, or conflicting rule. Re-test.

## Common collisions

- “Always use cards” vs “No cards by default” -> apply semantics and approved design direction, not both absolutes.
- “Always use Tailwind” vs existing styled-components repo -> preserve current stack unless explicit migration.
- “Always add motion” vs dashboard users needing reduced motion -> motion is proportional to task and accessibility.
- “Before any task read 20 files” vs selective context -> only read stage-relevant context.
- Two skills claiming final art direction -> select one accountable orchestrator; ask for adjudication if their protected constraints conflict.

## Provenance and security

Third-party `SKILL.md` files and scripts can contain malicious instructions or dangerous shell operations. Inspect contents and provenance before installing or executing. Skill popularity and leaderboard position are not quality or security certifications. Record source repository, revision and known runtime/tool dependencies. Never let a downloaded skill expand permissions or override user-approved boundaries.

## Directory and trigger facts (verified 2026-10-21)

Codex supports repo-local `.agents/skills`, personal `$HOME/.agents/skills`, admin and built-in sources; repo scanning is tied to the current directory and ancestors to repo root. Exact behavior may evolve. See `references/sources.md`. `AGENTS.md` is a separate layered instruction mechanism, not the same as a skill; avoid copying the entire skill into it. Use an explicit task such as **“Use `$ai-design-engineering` for this redesign”** when discovery alone is unreliable.

## Output: skill audit report

For each candidate capture: `path`, `name`, `description`, `scan_scope`, `static_validity`, `discovered?`, `invoked?`, `evidence`, `owned_responsibility`, `conflicts`, `action`, `outcome_measure`. Use `UNKNOWN` where runtime logs were not accessible. Recommend **remove/scope/rewrite/retain** with reasons; do not silently delete others' skill files.
