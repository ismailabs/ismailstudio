# ChatGPT imagery, mockups and asset strategy

Use this when generating concepts, assets, or design specifications. Image generation requires an **actual image tool** in the current environment; the skill does not create one. Never describe a text prompt as a finished image. Concept images and screenshots of implemented UIs are different evidence classes.

## Generate in two passes to protect quality and tokens

**Pass 1 — Divergence:** 3–5 deliberately different **homepage** art-direction mockups, each with distinct composition, image treatment, and typography intent. Anchor them to truthful brand facts and real site content. Label output files `concept-A-home-desktop.png` etc., note model/tool if known, and record what differs structurally. They are *conceptual*; small text may be inaccurate.

**Pass 2 — Expansion after human selection:** for **every page/route**, produce a **desktop and a mobile** reference matching the selected art direction, plus separate images or annotated references for consequential states (nav open, filtered results, detail view, hover/focus behavior if perceptible, booking modal, empty/error states where needed). Use consistent site-wide assets/tokens. Group routes into small batches, review coherence, and regenerate weak images selectively.

Never claim mockups capture working behavior, keyboard focus, responsive constraints or animation timing; describe such requirements in accompanying text.

## Two output categories

- **UI mockup/reference:** a rendered image that communicates composition, type hierarchy, colors, spatial relationships, imagery, and major controls. It is an implementation reference, **not** a raw frontend asset.
- **Deployable asset:** photography, editorial image, illustration, icon, texture, etc. with known provenance and an intended placement. Prefer imagery without baked-in UI, badges, text or floating component frames so code can render real text and controls. Preserve creator rights and licenses.

Do not place a whole AI-generated mockup as the interactive website background. Reconstruct UI elements with semantic, responsive code. Use component/system specs to resolve contradictions or inaccurate text inside generated images.

## Minimal reliable mockup request (customize placeholders using confirmed project facts)

> Create a **conceptual website design reference image**, not implementation code, for [brand / page / audience]. The approved design direction is [visual thesis]. Show [real content hierarchy and primary action]. Visual character: [composition, typography, palette, photo direction]. Distinctive brand expression: [signature]. Respect [locale and product constraints]. Avoid [identified anti-patterns]. Target [desktop wide / mobile narrow], with believable hierarchy, readable contrasts, and clear safe areas. Do not invent product facts. Represent uncertain fine print as placeholders outside the final UI specification.

Use no more concept detail than needed to convey the thesis. If tool outputs are unsuitable, critique a specific issue (composition, image crop, or text hierarchy) and regenerate that region/design rather than repeating the same broad prompt.

## Route + viewport matrix

Construct an inventory of all real routes, templates and key states before expanding the approved design. For each, record:

| Field | Meaning |
| --- | --- |
| `route_id` | Stable logical page ID, not necessarily literal URL |
| `route` | Canonical path or route parameter pattern |
| `desktop_mockup` | Actual file path and concept version |
| `mobile_mockup` | Actual file path and concept version |
| `key_states` | State IDs, interaction outcome, evidence file if visualized |
| `content_source` | Trustworthy source or user supplied copy |
| `exceptions` | Responsive adaptation or tool-imposed limitation |

Do not mark a route covered when files are missing. The handoff should include every required page's desktop/mobile mockups; where generation is blocked, note it rather than silently reducing scope.

## Fidelity hierarchy for Codex

1. **Invariants:** brand hierarchy, hero concept, image composition, distinctive typography roles, section narrative, visual rhythm, approved palette, interaction concept.
2. **Adaptable:** exact spacing, breakpoints, crops, text wrapping, navigation placement, state layouts, technical animation method, provided their intended effect survives.
3. **Must not blindly reproduce:** generated illegible text, impossible layout geometry, inaccessible contrast, fake UI interactions, unlicensed trademarks, fabricated business content.

## Asset registry

For each asset track `id`, path, origin (existing/generated/licensed), generation prompt/reference or URL, license/permission status, subject, crop/safe area, alt-text intent, pages used, and approval status. When original repo imagery is suitable, reuse it. Generate replacements only if available and authorized. Avoid using a remote hotlinked image as a deployment asset without appropriate permission and reliability safeguards.

## Transport from ChatGPT to Codex

Images do not magically transfer between conversations or accounts. Export assets and mockups into a project folder or attach them to the Codex task; include paths in the design manifest. Confirm files are readable in Codex's actual environment. If no shared filesystem exists, create a portable handoff bundle or describe precisely which files must be uploaded.
