# Operational state machine: from brief to verified experience

**Purpose:** enforce traceable transitions without forcing a heavyweight process onto trivial tasks. `SKILL.md` is the routing authority; this file expands exceptional states, not the entire design handbook.

## Modes

- **Focused:** minor visual bug or one component; baseline -> minimal change -> browser evidence -> targeted tests. No forced multiple concepts.
- **Full:** major redesign, new website, extensive visual identity change; all stages below. Default when user requests significant visual reinvention.
- **Recovery:** a prior AI attempt is disappointing; begin with forensic comparison of original brief, actual screenshots, installed/used skills, and any missing review loop. Do **not** generate a new design until failure is diagnosed.

## State transitions

| State | Inputs | Required output | Advancement rule |
| --- | --- | --- | --- |
| S0 Intake | User brief, repository access (if any), screenshots | Baseline requirements, inventory, observed limitations, capability map | Critical project constraints known or explicitly unresolved |
| S1 Diagnose | Existing skills, instruction hierarchy, previous prompts/results | Evidence-based suspected failure modes | Unknowns are labeled, not guessed |
| S2 Creative research | Brand facts, content, audience, references | Creative brief and mood-board notes | Distinctiveness test and audience fit defined |
| S3 Concept divergence | Approved brief, image tool/reference access | 3–5 distinct homepage concepts with comparison | Real image artifacts exist or alternative documented |
| S4 Human selection | Concepts, criteria | Approved concept/version and immutable design principles | Explicit selection obtained; no premature implementation |
| S5 Design specification | Approved concept, page inventory | Desktop+mobile mockups **for every route** and key state, asset register, design tokens, interaction notes | Manifest links files; coverage complete or blocked |
| S6 Engineering handoff | All S5 assets/specs | Executable acceptance criteria and Codex work packet | Every critical design invariant is testable or reviewable |
| S7 Build | Repository, working branch, handoff | Implemented app with traceable file changes | App launches; functional tests and visual review can begin |
| S8 Browser verification | Running app and browser | Desktop/mobile screenshots, motion evidence, defects, technical test reports | Failures identified, not concealed |
| S9 Refine | Defect log and approved direction | Incremental fixes; new captures; cycle record | Re-evaluate gate failures; default three focused passes |
| S10 Release report | S9 evidence | Factual results, limitations, next action | All mandatory gates pass, or explicitly blocked/failed |

### Do not confuse these artifacts

- **Concept mockup:** generated *aspirational* image. Not a web page, not a runtime measurement.
- **Reference screenshot:** capture from another design, with rights and intended design principle noted.
- **Implementation screenshot:** actual browser output of code being built.
- **Evidence manifest:** machine-readable list of real files and reported checks; file presence alone is not design evaluation.
- **Test report:** observed command, environment, exit code/result; no invented metrics.

## Change control and approvals

Human approval is required for final art-direction selection; approval already recorded in the current task counts. Codex can autonomously make scoped, reversible changes within the approved direction. Ask again only when a *material* change would alter identity, site scope, key content, existing functionality or consequences. Seek separate authorization before external publication, deployment, destructive edits, sharing private information, new sensitive access, or substantial purchasing/cost commitment. Use source code branches/snapshots when feasible; do not overwrite uncommitted work without permission.

## Adaptive work budget

Default **three** focused review passes: (1) macro composition and hero, (2) cross-page details and motion, (3) responsive polish and regressions. This order is a suggestion, not a substitute for severity triage. Fix critical failures first regardless of pass number. Continue only if resources allow and substantive visual or technical defects remain. Avoid endless optimization for an arbitrary score.

## Recovery conditions

- No image generation: use approved examples/manual mockups or deliver a concept spec; mark image-based design generation blocked.
- No repo access: deliver an annotated design packet and explicit implementer requirements, not fictitious code changes.
- No browser: run available static checks and request screenshots; mark visual and interaction verification not performed.
- Conflicting skills: select one accountable skill per role, explain exclusion decisions, and preserve higher-priority/project requirements.
- Mockups violate content truth/legibility: correct the design spec and concept inputs before translating into code.
- Failing mandatory gate: attempt scoped fixes or report `FAIL`/`BLOCKED`; do not call the project validated.
- Model context truncation: rebuild from authoritative handoff and latest evidence, not an unchecked memory summary.

## Completion record

Use these exact verification states: `PASS` (observed and supported), `FAIL` (observed defect), `BLOCKED` (required tool/input missing), `NOT_TESTED` (could test but did not), `NOT_APPLICABLE` (reason given). A subjective human aesthetic judgment is recorded as `APPROVED` or `NOT_APPROVED`, never forged as an automated PASS.
