#!/usr/bin/env python3
"""Static, read-only inventory of repository-local Codex skills.

This reports possible conflicts and discovery paths; it CANNOT establish
runtime invocation, adherence, or whether a skill improved the design.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import sys


def fields(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    t = path.read_text(encoding="utf-8-sig", errors="replace")
    m = re.match(r"\A---\s*\n(.*?)\n---\s*\n", t, flags=re.S)
    if not m:
        return {}
    result = {}
    for k, v in re.findall(r"^([a-z][a-z0-9_-]*):\s*([^\n]*)", m.group(1), re.M):
        result[k] = v.strip().strip('"\'')
    return result


def inventory(repo: Path, cwd: Path | None = None, include_home: bool = False) -> dict:
    repo = repo.resolve()
    cwd = (cwd or repo).resolve()
    warnings = []
    if not repo.is_dir():
        return {"error": f"Not a directory: {repo}"}
    try:
        cwd.relative_to(repo)
    except ValueError:
        return {"error": "--cwd must be inside --repo"}
    paths = []
    cursor = cwd
    while True:
        paths.append(cursor)
        if cursor == repo:
            break
        cursor = cursor.parent
    paths.reverse()
    if include_home:
        paths.append(Path.home())
    skills = []
    instruction_files = []
    for parent in paths:
        for filename in ("AGENTS.override.md", "AGENTS.md"):
            if (parent / filename).is_file():
                instruction_files.append(str(parent / filename))
        base = parent / ".agents" / "skills"
        if not base.is_dir():
            continue
        for folder in sorted(base.iterdir()):
            if not folder.is_dir():
                continue
            skill_file = folder / "SKILL.md"
            meta = fields(skill_file)
            name = meta.get("name", "")
            status = "OK" if name == folder.name and bool(meta.get("description")) else "INVALID_OR_INCOMPLETE"
            skills.append({
                "folder": str(folder), "name": name or None,
                "description": meta.get("description", ""), "static_status": status,
                "scope": "HOME" if parent == Path.home() and include_home else "REPO",
                "note": "Static presence only; invocation is unknown"
            })
            if status != "OK":
                warnings.append(f"Review invalid/incomplete frontmatter: {skill_file}")
    names = {}
    for item in skills:
        if item["name"]:
            names.setdefault(item["name"], []).append(item["folder"])
    for name, occurrences in names.items():
        if len(occurrences) > 1:
            warnings.append(f"Duplicate skill name {name}: {', '.join(occurrences)}")
    return {"repository": str(repo), "working_directory": str(cwd),
            "skill_count": len(skills), "skills": skills,
            "agents_md_candidates": instruction_files,
            "warnings": warnings,
            "limitations": ["Does not inspect Codex selector or tool traces",
                            "Does not resolve actual AGENTS.md override precedence",
                            "Does not scan remote Codex Cloud, admin or built-in skills",
                            "Does not establish skill activation, compliance or aesthetic effect"]}


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", required=True, type=Path)
    p.add_argument("--cwd", type=Path, help="Codex launch folder; defaults to repository root")
    p.add_argument("--include-home", action="store_true", help="Also inspect personal ~/.agents/skills")
    p.add_argument("--json", action="store_true", help="Machine-readable output")
    args = p.parse_args()
    report = inventory(args.repo, args.cwd, args.include_home)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 2 if "error" in report else 0


if __name__ == "__main__":
    raise SystemExit(main())
