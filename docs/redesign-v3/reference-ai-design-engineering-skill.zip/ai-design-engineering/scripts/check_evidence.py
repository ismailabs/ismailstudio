#!/usr/bin/env python3
"""Check local browser evidence manifest structure/coverage and file existence.

Does not inspect pixels, motion, accessibility, browser state or truth of claims.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

STATUSES = {"PASS", "FAIL", "BLOCKED", "NOT_TESTED", "NOT_APPLICABLE"}
MANDATORY_GATES = {"functional", "content", "responsive", "accessibility", "asset_integrity", "build_tests", "motion", "visual_fidelity", "coverage"}


def check(manifest: Path) -> list[str]:
    errors: list[str] = []
    manifest = manifest.resolve()
    try:
        obj = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        return [f"Cannot parse manifest {manifest}: {e}"]
    if not isinstance(obj, dict):
        return ["Manifest root must be a JSON object"]
    routes = obj.get("required_routes")
    viewports = obj.get("required_viewports")
    captures = obj.get("captures", [])
    gates = obj.get("gates", [])
    if not isinstance(routes, list) or not routes or not all(isinstance(x, str) and x for x in routes):
        errors.append("required_routes must be a nonempty list of IDs")
        routes = []
    if not isinstance(viewports, list) or not viewports or not all(isinstance(x, str) and x for x in viewports):
        errors.append("required_viewports must be a nonempty list of viewport IDs")
        viewports = []
    if not isinstance(captures, list):
        errors.append("captures must be a list")
        captures = []
    if not isinstance(gates, list):
        errors.append("gates must be a list")
        gates = []
    root_value = obj.get("artifact_root", "./")
    if not isinstance(root_value, str):
        errors.append("artifact_root must be a path string")
        root_value = "./"
    artifact_root = Path(root_value)
    artifact_root = artifact_root if artifact_root.is_absolute() else manifest.parent / artifact_root
    artifact_root = artifact_root.resolve()
    seen = set()
    for idx, c in enumerate(captures):
        if not isinstance(c, dict):
            errors.append(f"captures[{idx}]: expected object")
            continue
        rid, vp = c.get("route_id"), c.get("viewport")
        state = c.get("state", "default")
        path = c.get("path")
        key = (rid, vp, state)
        if key in seen:
            errors.append(f"Duplicate capture {key}")
        seen.add(key)
        if rid not in routes:
            errors.append(f"captures[{idx}]: unexpected route {rid!r}")
        if vp not in viewports:
            errors.append(f"captures[{idx}]: unexpected viewport {vp!r}")
        if not isinstance(path, str) or not path.strip():
            errors.append(f"captures[{idx}]: missing path")
        else:
            resolved = Path(path)
            resolved = resolved.resolve() if resolved.is_absolute() else (artifact_root / resolved).resolve()
            if not resolved.is_relative_to(artifact_root):
                errors.append(f"captures[{idx}]: path escapes artifact_root")
            elif not resolved.is_file():
                errors.append(f"captures[{idx}]: missing evidence file: {resolved}")
        if c.get("source") not in {"browser_screenshot", "browser_recording", "trace"}:
            errors.append(f"captures[{idx}]: source must be browser_screenshot/browser_recording/trace")
        if c.get("source") == "browser_screenshot":
            if not (isinstance(c.get("width"), int) and c["width"] > 0 and isinstance(c.get("height"), int) and c["height"] > 0):
                errors.append(f"captures[{idx}]: screenshot needs positive integer width/height")
    for rid in routes:
        for vp in viewports:
            if (rid, vp, "default") not in seen:
                errors.append(f"Missing default capture for route={rid}, viewport={vp}")
    gate_ids = set()
    for i, gate in enumerate(gates):
        if not isinstance(gate, dict):
            errors.append(f"gates[{i}]: expected object")
            continue
        gid = gate.get("id")
        status = gate.get("status")
        if not isinstance(gid, str) or not gid:
            errors.append(f"gates[{i}]: missing id")
        elif gid in gate_ids:
            errors.append(f"Duplicate gate id {gid}")
        gate_ids.add(gid)
        if status not in STATUSES:
            errors.append(f"gates[{i}]: invalid status {status!r}")
        if status in {"BLOCKED", "NOT_TESTED", "NOT_APPLICABLE"} and not gate.get("reason"):
            errors.append(f"gates[{i}]: {status} needs reason")
        if status == "PASS" and not gate.get("evidence"):
            errors.append(f"gates[{i}]: PASS needs evidence reference(s)")
    missing_gates = MANDATORY_GATES - gate_ids
    if missing_gates:
        errors.append("Missing mandatory gate statuses: " + ", ".join(sorted(missing_gates)))
    if obj.get("human_creative_approval") not in {"APPROVED", "NOT_APPROVED", "PENDING"}:
        errors.append("human_creative_approval must be APPROVED, NOT_APPROVED or PENDING")
    if not isinstance(obj.get("cycles", []), list):
        errors.append("cycles must be a list")
    return errors


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", required=True, type=Path)
    args = p.parse_args()
    errors = check(args.manifest)
    if errors:
        print("FAIL: evidence manifest needs corrections", file=sys.stderr)
        for e in errors:
            print(" -", e, file=sys.stderr)
        return 1
    print("PASS: manifest structure, declared route/viewport coverage and capture file presence")
    print("IMPORTANT: browser authenticity, aesthetics, technical tests and PASS evidence truth are NOT verified.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
