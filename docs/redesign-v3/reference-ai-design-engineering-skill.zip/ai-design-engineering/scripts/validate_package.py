#!/usr/bin/env python3
"""Static local integrity validator for an Agent Skill folder. Stdlib only.

It does not execute SKILL.md, invoke Codex, or validate real design quality.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import re
import sys

NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
LINK = re.compile(r"(?<!!)\[[^\]]*\]\(([^)]+)\)")


def frontmatter(path: Path) -> tuple[dict[str, str], list[str]]:
    errors: list[str] = []
    if not path.is_file():
        return {}, [f"Missing {path}"]
    text = path.read_text(encoding="utf-8-sig")
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, [f"{path}: missing opening YAML ---"]
    try:
        end = next(i for i in range(1, len(lines)) if lines[i].strip() == "---")
    except StopIteration:
        return {}, [f"{path}: missing closing YAML ---"]
    values: dict[str, str] = {}
    # Standard validation should use skills-ref/PyYAML; this small utility
    # intentionally understands only the simple scalar fields it needs.
    for line in lines[1:end]:
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = re.match(r"^([a-z][a-z0-9_-]*):\s*(.*)$", line)
        if match:
            key, value = match.groups()
            if key in values:
                errors.append(f"{path}: duplicate frontmatter key {key}")
            values[key] = value.strip().strip('"\'')
        elif not line.startswith((" ", "\t")):
            errors.append(f"{path}: unsupported malformed frontmatter line: {line!r}")
    return values, errors


def validate(root: Path) -> list[str]:
    errors: list[str] = []
    root = root.resolve()
    skill = root / "SKILL.md"
    data, parse_errors = frontmatter(skill)
    errors.extend(parse_errors)
    name = data.get("name", "")
    description = data.get("description", "")
    if not NAME.fullmatch(name) or len(name) > 64:
        errors.append(f"Invalid skill name: {name!r}")
    if name != root.name:
        errors.append(f"Skill name {name!r} must match folder {root.name!r}")
    if not (1 <= len(description) <= 1024):
        errors.append("Skill description must contain 1–1024 characters")
    if len(data.get("compatibility", "")) > 500:
        errors.append("Compatibility field exceeds 500 characters")
    for required in ("README.md", "references/workflow.md", "references/skill-orchestration.md", "references/quality-gates.md", "references/context-engineering.md"):
        if not (root / required).is_file():
            errors.append(f"Missing required packaged file: {required}")
    for md in root.rglob("*.md"):
        content = md.read_text(encoding="utf-8-sig")
        # This ignores links in fenced blocks as much as possible and keeps
        # file checks intentionally conservative.
        unfenced = re.sub(r"```.*?```", "", content, flags=re.S)
        for raw in LINK.findall(unfenced):
            url = raw.split(' "', 1)[0].strip()
            if url.startswith(("http:", "https:", "mailto:", "#", "data:")) or "<" in url:
                continue
            local = (md.parent / url.split("#", 1)[0]).resolve()
            if not local.is_relative_to(root) or not local.exists():
                errors.append(f"Broken or escaping local link {md.relative_to(root)} -> {url}")
    return errors


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("path", nargs="?", default=".", help="Agent Skill directory")
    args = ap.parse_args()
    root = Path(args.path)
    failures = validate(root)
    if failures:
        for f in failures:
            print("ERROR:", f, file=sys.stderr)
        return 1
    print(f"PASS: static structure and local links: {root.resolve()}")
    print("NOTE: run `skills-ref validate` if available for full frontmatter/spec checking.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
