# Optional addition to an existing repository's `AGENTS.md`

Merge this *section* into your existing instructions only after checking for conflicts. Do not overwrite the file or create duplicate universal instructions.

```markdown
## Visual-first frontend work
For significant website design/redesign, use the `ai-design-engineering` Agent Skill in `.agents/skills/ai-design-engineering/`. Follow its phase gates for approved art direction, image-led mockups, browser review and accessibility/performance checks. Preserve this repository's actual requirements and existing frontend stack. For small fixes or non-visual tasks, avoid loading the complete design workflow. Never report visual validation without actual rendered evidence.
```

Keep architecture, build commands, and other repo-specific guidance in the existing `AGENTS.md`. The skill describes *how* to run the design workflow; project instructions describe *what constraints apply here*. Codex instruction inheritance and overrides may alter what loads, so confirm discovery in the actual runtime.
