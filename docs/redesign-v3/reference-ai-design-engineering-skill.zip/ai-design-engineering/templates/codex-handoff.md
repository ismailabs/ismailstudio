# Codex visual-first execution handoff — [project]

## Mission

Implement the **approved** art direction as a functioning website, not a generic interpretation. Use the `ai-design-engineering` skill when available. Respect existing repository instructions and current task permissions.

## Authoritative input paths

- Repository and starting commit:
- Approved creative brief:
- Approved concept ID / version / human approval:
- Design specification / route inventory:
- Actual desktop/mobile mockup files (must be readable):
- Deployable assets, provenance and permissions:
- Nonnegotiable content and functionality:
- Existing relevant skills selected for specialized work:

## Build constraints

- Existing stack, build/test commands and route architecture:
- Functionality to preserve:
- Visual invariants (list 3–8, each mapped to a concept/mockup):
- Responsive adaptations that are authorized:
- Interaction and motion specification:
- Accessibility/performance requirements:
- No-go actions without separate authorization:

## Execution contract

1. Audit current site and verify installed skills; log where visual specification or tooling is missing.
2. Implement a representative homepage hero and one interior section; capture rendered evidence before propagating patterns widely.
3. Implement every approved route and key state; render real UI rather than using the mockup image as an interactive page.
4. Run available build/functional/browser checks and capture desktop/mobile screenshots. Compare actual captures with approved references.
5. Resolve the highest-impact faults; default to three focused visual review cycles with evidence.
6. Record `PASS`, `FAIL`, `BLOCKED`, `NOT_TESTED` or `NOT_APPLICABLE` for each mandatory gate. Do not claim what was not tested.
7. Deliver file change summary, route coverage, browser evidence paths, design deviations, remaining issues and the next action.

## Acceptance checklist

- [ ] All original required routes/features/content preserved
- [ ] Approved concept's recognizable visual signature appears in rendered site
- [ ] Real desktop/mobile captures available for each route, or documented blocker
- [ ] No major overflow/overlap/focus or navigation regressions
- [ ] Primary interactive states and reduced-motion behavior assessed
- [ ] Important images/assets load and have an accepted usage source
- [ ] Visual differences are reviewed; weak sections improved
- [ ] No invented test pass, screenshot, license, performance number or deployment

Do not seek renewed creative approval for routine technical adaptations. Ask if a proposed change materially alters the approved concept, user-facing commitments, or authorized scope.
