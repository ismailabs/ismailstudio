# Creative brief — [project / version]

> Replace brackets with verified project facts. Use `Unknown` rather than invented business details.

## Authority and scope

- Project / repository / reference commit:
- Owner / approving human:
- New site or redesign; scope of routes:
- Existing features/content that must survive:
- Existing visual constraints to preserve or intentionally replace:
- Permissions granted for assets, code edits, external research, deployment:
- Available tools verified in this session:

## Audience and brand

- Primary audience and important secondary audiences:
- Visitor's top task(s):
- Brand positioning, vocabulary and authenticity constraints:
- Evidence/source of brand facts:
- Emotional arc: arrival -> exploration -> decision -> action:
- Category conventions to retain / patterns to challenge:

## Creative direction hypotheses

- Visual thesis:
- Brand thesis:
- Distinctive visual signature:
- Preferred design principles:
- Anti-patterns / negative references:
- Reference URLs or paths with notes on *specific qualities*, not copying:
- Photo / illustration requirements and provenance:
- Intended motion philosophy:

## Approval

- Concept candidates (3–5):
- Approved concept ID and version:
- Human approval quote/date:
- Protected design invariants:
- Known risks/unknowns:
