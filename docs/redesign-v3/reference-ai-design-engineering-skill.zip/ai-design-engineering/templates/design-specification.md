# Design specification — [project] / [approved concept/version]

## Approved visual system

| Concern | Invariant | Technical adaptation allowed |
| --- | --- | --- |
| Brand mark/name and first-viewport hierarchy | | |
| Composition, narrative rhythm, hero focus | | |
| Typography roles and font availability | | |
| Color, surfaces and accessibility contrast | | |
| Photography/illustration treatment | | |
| Interaction states and signature motion | | |

## Routes and visual coverage

| Route ID | URL / route shape | Desktop mockup path | Mobile mockup path | Key state references | Content source |
| --- | --- | --- | --- | --- | --- |
| home | / | | | | |

Record exact paths to existing attachments/files. **Every required route needs both desktop and mobile references in a full design workflow.** If a tool is unavailable, mark blocked; do not invent path strings.

## Responsive behavior

- Viewport widths or tested categories:
- Hero safe areas and crop rules:
- Content order/priority changes:
- Navigation and controls on small screens:
- Breakpoints as behavior (not arbitrary numbers):
- Text wrapping, overflow, localization considerations:

## Interaction contracts

| Component / route | Trigger | State result | Keyboard + touch support | Motion / reduced-motion fallback |
| --- | --- | --- | --- | --- |

## Asset register

| Asset ID | File/path | Source, usage rights | Intended crop and alt text | Used on |
| --- | --- | --- | --- | --- |

## Constraints, evidence and exceptions

- Must-keep features/content inventory:
- Required accessibility checks:
- Performance constraints (with evidence source, not invented targets):
- Design ambiguities requiring human decision:
- Known generated-image inaccuracies to ignore in code:
- Approved deviations from mockup:
- Review manifest path:
