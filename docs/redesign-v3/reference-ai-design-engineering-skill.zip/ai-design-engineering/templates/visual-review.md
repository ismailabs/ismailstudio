# Visual review and final quality report — [project / run / date]

## Setup and evidence

- Source commit / branch / runtime:
- Tool + browser/device profiles actually used:
- Approved concept/specification versions:
- Baseline screenshots (if available):
- Final screenshots/recordings manifest:
- Scope of review, untested routes/states:

## Hard gates

Allowed status: `PASS`, `FAIL`, `BLOCKED`, `NOT_TESTED`, `NOT_APPLICABLE` (reason required for the last three).

| Gate | Status | Evidence / test method | Defect ID / blocker |
| --- | --- | --- | --- |
| Route and task functionality | | | |
| Content integrity | | | |
| Desktop/mobile usability | | | |
| Accessibility and focus | | | |
| Asset load / provenance | | | |
| Build/tests / no blockers | | | |
| Motion/reduced motion | | | |
| Fidelity to approved design invariants | | | |
| Browser review coverage | | | |

## Perceptual review (narrative; scores optional)

- Art direction and brand distinction:
- First-screen focal hierarchy:
- Originality and specificity:
- Typography, image quality and crop:
- Emotional fit and narrative:
- Consistency across routes:
- Motion coherence:
- Human creative approval: `APPROVED` / `NOT_APPROVED` / `PENDING`:

## Defect ledger

| ID | Severity P0–P3 | Route/viewport/state | Observed defect | Evidence path | Fix and status |
| --- | --- | --- | --- | --- | --- |

## Iteration history

| Cycle | Visual problem targeted | Changes made | Before/after evidence | Regression checks |
| --- | --- | --- | --- | --- |
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |

## Delivery summary

- Implemented route and state inventory:
- Substantive design differences from baseline:
- Open P0/P1 defects, if any:
- Unverified/blocked gates:
- Exact next action/approval needed:
