"""Unit tests for the package's stdlib validators."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(name: str):
    p = ROOT / "scripts" / f"{name}.py"
    spec = importlib.util.spec_from_file_location(name, p)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class PackageValidation(unittest.TestCase):
    def test_real_package(self):
        self.assertEqual(load("validate_package").validate(ROOT), [])

    def test_bad_frontmatter(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "bad-skill"
            root.mkdir()
            (root / "SKILL.md").write_text("No YAML", encoding="utf-8")
            self.assertTrue(load("validate_package").validate(root))


class SkillAudit(unittest.TestCase):
    def test_duplicate_names(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            for folder in (repo / ".agents/skills/test-skill", repo / "sub/.agents/skills/test-skill"):
                folder.mkdir(parents=True)
                (folder / "SKILL.md").write_text("---\nname: test-skill\ndescription: Test skill.\n---\n", encoding="utf-8")
            report = load("audit_skills").inventory(repo, repo / "sub")
            self.assertEqual(report["skill_count"], 2)
            self.assertTrue(any("Duplicate" in w for w in report["warnings"]))


class EvidenceValidation(unittest.TestCase):
    def test_complete_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for vp in ("desktop", "mobile"):
                (root / f"home-{vp}.png").write_bytes(b"fixture")
            manifest = {
                "artifact_root": ".",
                "required_routes": ["home"],
                "required_viewports": ["desktop", "mobile"],
                "captures": [{"route_id": "home", "viewport": vp, "state": "default", "source": "browser_screenshot", "width": 1400 if vp == "desktop" else 390, "height": 800, "path": f"home-{vp}.png"} for vp in ("desktop", "mobile")],
                "gates": [{"id": gate, "status": "NOT_TESTED", "reason": "test fixture", "evidence": []} for gate in load("check_evidence").MANDATORY_GATES],
                "human_creative_approval": "PENDING", "cycles": []
            }
            path = root / "manifest.json"
            path.write_text(json.dumps(manifest), encoding="utf-8")
            self.assertEqual(load("check_evidence").check(path), [])
            (root / "home-mobile.png").unlink()
            self.assertTrue(any("missing evidence file" in err for err in load("check_evidence").check(path)))


if __name__ == "__main__":
    unittest.main()
